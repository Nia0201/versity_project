


<?php $__env->startSection('content'); ?>

<!-- Recent Sales -->
<section class="section">
      <div class="row">
      <div class="d-flex justify-content-center">

<div class="col-8">
<div class="card">
  <div class="card-body">
    <h2 class="text-center">Verifikasi Internet</h2>

<ul>
  <div class="filter">
    <div class="col-md-4">
    <label for="inputState" class="form-label">Lokasi</label>
      <select id="inputState" class="form-select">
          <option selected>Choose...</option>
            <option value="1">Karawang</option>
            <option value="2">Jakarta</option>
        </select>
      </div>

    <div class="filter">
    <div class="col-md-4">
    <label for="inputState" class="form-label">Bulan Pemakaian</label>
      <select id="inputState" class="form-select">
          <option selected>Choose...</option>
            <option value="1">Januari</option>
            <option value="2">Februari</option>
            <option value="3">Maret</option>
            <option value="4">April</option>
            <option value="5">Mei</option>
            <option value="6">Juni</option>
            <option value="7">Juli</option>
            <option value="8">Agustus</option>
            <option value="9">September</option>
            <option value="10">Oktober</option>
            <option value="11">November</option>
            <option value="12">Desember</option>
        </select>
      </div>

    <div class="filter">
    <div class="col-md-4">
    <label for="inputState" class="form-label">Bulan Pembayaran</label>
      <select id="inputState" class="form-select">
          <option selected>Choose...</option>
            <option value="1">Januari</option>
            <option value="2">Februari</option>
            <option value="3">Maret</option>
            <option value="4">April</option>
            <option value="5">Mei</option>
            <option value="6">Juni</option>
            <option value="7">Juli</option>
            <option value="8">Agustus</option>
            <option value="9">September</option>
            <option value="10">Oktober</option>
            <option value="11">November</option>
            <option value="12">Desember</option>
        </select>
      </div>
</ul>

<table class="table table-borderless datatable">
                    <thead>
                      <tr>
                        <th scope="col">No</th>
                        <th scope="col">No Telepon</th>
                        <th scope="col">Pemakaian</th>
                        <th scope="col">Biaya Admin</th>
                        <th scope="col">Total</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <th scope="row"><a href="#">#1</a></th>
                        <td>0895324870379</td>
                        <td>150.000</td>
                        <td>2.000</td>
                        <td>152.000</td>
                        <td><span class="badge bg-success">Approved</span></td>
                      </tr>
                      <tr>
                        <th scope="row"><a href="#">#1</a></th>
                        <td>0895324870379</td>
                        <td>150.000</td>
                        <td>2.000</td>
                        <td>152.000</td>
                        <td><span class="badge bg-success">Approved</span></td>
                      </tr>
                      <tr>
                        <th scope="row"><a href="#">#1</a></th>
                        <td>0895324870379</td>
                        <td>150.000</td>
                        <td>2.000</td>
                        <td>152.000</td>
                        <td><span class="badge bg-success">Approved</span></td>
                      </tr>
                      <tr>
                        <th scope="row"><a href="#">#1</a></th>
                        <td>0895324870379</td>
                        <td>150.000</td>
                        <td>2.000</td>
                        <td>152.000</td>
                        <td><span class="badge bg-success">Approved</span></td>
                      </tr>
                      <tr>
                        <th scope="row"><a href="#">#1</a></th>
                        <td>0895324870379</td>
                        <td>150.000</td>
                        <td>2.000</td>
                        <td>152.000</td>
                        <td><span class="badge bg-success">Approved</span></td>
                      </tr>
                    </tbody>
                  </table>
                  <div class="text-right">
                    <button type="submit" class="btn btn-primary">Approve</button>
                  </div>

                </div>

              </div>
            </div><!-- End Recent Sales -->
      

<?php echo $__env->yieldContent('content'); ?>
<?php $__env->stopSection(); ?>
                
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PERURI\hros\resources\views/verifinternet.blade.php ENDPATH**/ ?>