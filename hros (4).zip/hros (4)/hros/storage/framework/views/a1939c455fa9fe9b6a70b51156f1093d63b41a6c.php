

<?php $__env->startSection('content'); ?>

<div class="card">
            <div class="card-body">
            <h2 class="text-center">Database Master Data Listrik</h2>

            <ul>
            <div class="text-right">
                    <button type="submit" class="btn btn-primary">Unggah Data</button>
            </div>
            </ul>

              <!-- List group with Links and buttons -->
              <div class="list-group">
                <button type="button" class="list-group-item list-group-item-action">Database Listrik Bulan Januari</button>
                <button type="button" class="list-group-item list-group-item-action">Database Listrik Bulan Februari</button>
                <button type="button" class="list-group-item list-group-item-action">Database Listrik Bulan Maret</button>
                <button type="button" class="list-group-item list-group-item-action">Database Listrik Bulan April</button>
              </div><!-- End List group with Links and buttons -->

            </div>
          </div>

<?php echo $__env->yieldContent('content'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PERURI\hros\resources\views/listexcellistrik.blade.php ENDPATH**/ ?>