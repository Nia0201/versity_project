

<?php $__env->startSection('content'); ?>

<div class="m-3">
<div class="container px-4">
  <div class="row gx-5">
    <div class="col">
      <button class="border-0" type="submit" style="position: absolute; /*padding-left: 230px; padding-top: 245px;*/
        width: 50px;height: 50px;left: 75.5px; top: 95.5px;background: url(assets/back3.png);">
      </button>
      <div style="position: absolute; width: 1032.5px; height: 35.5px; left: 155px; top: 105.5px;
        background: #DFF6FF; border-radius: 10px;">
        <div class="text-center" style="font-family: 'Roboto'; font-style: normal; color: rgba(6, 40, 61, 0.79); font-weight: 400; font-size: 25.5px">
          <p>Master Data Listrik</p>
        </div>
      </div>
      <p style="position: absolute; left: 12.42%; right: 75.56%; top: 27.71%; bottom: 81.64%; font-family: 'Roboto';
        font-style: normal; font-weight: 600; font-size: 25.5px; line-height: 38px; color: rgba(6, 40, 61, 0.79);">Tempat: </p>
      <button class="border-0" style="position: absolute;left: 23.61%; right: 66.32%; top: 27.71%; bottom: 81.64%; font-family: 'Roboto';
        font-style: normal; font-weight: 400; font-size: 25px; line-height: 38px; color: rgba(6, 40, 61, 0.79);">Karawang
      </button>
      <button class="border-0" style="position: absolute;left: 23.61%; right: 40.32%; top: 27.71%; bottom: 81.64%; font-family: 'Roboto';
        font-style: normal; font-weight: 400; font-size: 25px; line-height: 38px; color: rgba(6, 40, 61, 0.79);">Jakarta
      </button>
      <p style="position: absolute; left: 12.42%; right: 75.56%; top: 38.71%; bottom: 65.64%; font-family: 'Roboto';
          font-style: normal; font-weight: 500; font-size: 20.5px; line-height: 38px; color: rgba(6, 40, 61, 0.79);">Bulan Pemakaian: </p>
      <select class="custom-select mr-sm-2" id="inlineFormCustomSelect" style="position: absolute; width: 150.5px; height: 30.5px; left: 320.5px;
        top: 225px; background: #FFFFFF; border: 2.5px solid #D9D9D9;">
        <option selected>Choose...</option>
        <option value="1">Januari</option>
        <option value="2">Februari</option>
        <option value="3">Maret</option>
        <option value="4">April</option>
        <option value="5">Mei</option>
        <option value="6">Juni</option>
        <option value="7">Juli</option>
        <option value="8">Agustus</option>
        <option value="9">September</option>
        <option value="10">Oktober</option>
        <option value="11">November</option>
        <option value="12">Desember</option>
      </select>
      <p style="position: absolute; left: 12.42%; right: 75.56%; top: 45.71%; bottom: 65.64%; font-family: 'Roboto';
          font-style: normal; font-weight: 500; font-size: 18.5px; line-height: 38px; color: rgba(6, 40, 61, 0.79);">Bulan Pembayaran: </p>
      <select class="custom-select mr-sm-2" id="inlineFormCustomSelect" style="position: absolute; width: 150.5px; height: 30.5px; left: 320.5px;
        top: 265px; background: #FFFFFF; border: 2.5px solid #D9D9D9;">
        <option selected>Choose...</option>
        <option value="1">Januari</option>
        <option value="2">Februari</option>
        <option value="3">Maret</option>
        <option value="4">April</option>
        <option value="5">Mei</option>
        <option value="6">Juni</option>
        <option value="7">Juli</option>
        <option value="8">Agustus</option>
        <option value="9">September</option>
        <option value="10">Oktober</option>
        <option value="11">November</option>
        <option value="12">Desember</option>
      </select>
      <div>
        <button type="submit" class="btn btn-primary btn-block mb-4" style="position: absolute;width: 100px; height: 35px; left: 850px;
          top: 310px; background: #1363DF; box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25); border-radius: 12.5px;;">
            <div class="text-center" style="font-family: 'Roboto'; font-style: normal; font-weight: 500; font-size: 16px;">
              <p>Unduh</p>
            </div>
        </button>
      </div>
      <div>
        <button type="submit" class="btn btn-primary btn-block mb-4" style="position: absolute;width: 100px; height: 35px; left: 1000px;
          top: 310px; background: #1363DF; box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25); border-radius: 12.5px;;">
            <div class="text-center" style="font-family: 'Roboto'; font-style: normal; font-weight: 500; font-size: 16px;">
              <p>Unggah</p>
            </div>
        </button>
      </div>
    </div>
  </div>
</div>
</div>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PERURI\hros\resources\views/mdlistrikkeuangan.blade.php ENDPATH**/ ?>