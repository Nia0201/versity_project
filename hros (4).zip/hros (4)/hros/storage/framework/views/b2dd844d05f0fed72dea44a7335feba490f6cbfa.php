


<?php $__env->startSection('content'); ?>

<!-- Recent Sales -->
<section class="section">
      <div class="row">
      <div class="d-flex justify-content-center">

<div class="col-10">
<div class="card">
  <div class="card-body">
    <h2 class="text-center">Master Data TV Kabel</h2>

<ul>
  <div class="filter">
    <div class="col-md-4">
    <label for="inputState" class="form-label">Lokasi</label>
      <select id="inputState" class="form-select">
          <option selected>Choose...</option>
            <option value="1">Karawang</option>
            <option value="2">Jakarta</option>
        </select>
      </div>

    <div class="filter">
    <div class="col-md-4">
    <label for="inputState" class="form-label">Bulan Pemakaian</label>
      <select id="inputState" class="form-select">
          <option selected>Choose...</option>
            <option value="1">Januari</option>
            <option value="2">Februari</option>
            <option value="3">Maret</option>
            <option value="4">April</option>
            <option value="5">Mei</option>
            <option value="6">Juni</option>
            <option value="7">Juli</option>
            <option value="8">Agustus</option>
            <option value="9">September</option>
            <option value="10">Oktober</option>
            <option value="11">November</option>
            <option value="12">Desember</option>
        </select>
      </div>

    <div class="filter">
    <div class="col-md-4">
    <label for="inputState" class="form-label">Bulan Pembayaran</label>
      <select id="inputState" class="form-select">
          <option selected>Choose...</option>
            <option value="1">Januari</option>
            <option value="2">Februari</option>
            <option value="3">Maret</option>
            <option value="4">April</option>
            <option value="5">Mei</option>
            <option value="6">Juni</option>
            <option value="7">Juli</option>
            <option value="8">Agustus</option>
            <option value="9">September</option>
            <option value="10">Oktober</option>
            <option value="11">November</option>
            <option value="12">Desember</option>
        </select>
      </div>
</ul>
<div class="text-right">
                    <button type="submit" class="btn btn-primary">Tambah</button>
                    <button type="submit" class="btn btn-primary">Edit</button>
                    <button type="submit" class="btn btn-primary">Unggah</button>
                    <button type="submit" class="btn btn-primary">Unduh</button>
                  </div>
<table class="table table-borderless datatable">
                    <thead>
                      <tr>
                        <th scope="col">No</th>
                        <th scope="col">Nomor Pegawai</th>
                        <th scope="col">Nama</th>
                        <th scope="col">No.Telepon</th>
                        <th scope="col">Pemakaian</th>
                        <th scope="col">Plafon</th>
                        <th scope="col">Roaming LN</th>
                        <th scope="col">Beban Pegawai</th>
                        <th scope="col">Beban Perusahaan</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <th scope="row"><a href="#">#1</a></th>
                        <td>4038</td>
                        <td><a href="#" class="text-primary">Nia Madu</a></td>
                        <td>0895324870379</td>
                        <td>150.000</td>
                        <td>500.000</td>
                        <td>2000</td>
                        <td>502.000</td>
                        <td>600.000</td>
                        <td><span class="badge bg-success">Approved</span></td>
                      </tr>
                      <tr>
                        <th scope="row"><a href="#">#1</a></th>
                        <td>4038</td>
                        <td><a href="#" class="text-primary">Nia Madu</a></td>
                        <td>0895324870379</td>
                        <td>150.000</td>
                        <td>500.000</td>
                        <td>2000</td>
                        <td>502.000</td>
                        <td>600.000</td>
                        <td><span class="badge bg-success">Approved</span></td>
                      </tr>
                      <tr>
                        <th scope="row"><a href="#">#1</a></th>
                        <td>4038</td>
                        <td><a href="#" class="text-primary">Nia Madu</a></td>
                        <td>0895324870379</td>
                        <td>150.000</td>
                        <td>500.000</td>
                        <td>2000</td>
                        <td>502.000</td>
                        <td>600.000</td>
                        <td><span class="badge bg-success">Approved</span></td>
                      </tr>
                      <tr>
                        <th scope="row"><a href="#">#1</a></th>
                        <td>4038</td>
                        <td><a href="#" class="text-primary">Nia Madu</a></td>
                        <td>0895324870379</td>
                        <td>150.000</td>
                        <td>500.000</td>
                        <td>2000</td>
                        <td>502.000</td>
                        <td>600.000</td>
                        <td><span class="badge bg-success">Approved</span></td>
                      </tr>
                      <tr>
                        <th scope="row"><a href="#">#1</a></th>
                        <td>4038</td>
                        <td><a href="#" class="text-primary">Nia Madu</a></td>
                        <td>0895324870379</td>
                        <td>150.000</td>
                        <td>500.000</td>
                        <td>2000</td>
                        <td>502.000</td>
                        <td>600.000</td>
                        <td><span class="badge bg-success">Approved</span></td>
                      </tr>
                    </tbody>
                  </table>
                  <div class="text-right">
                    <button type="submit" class="btn btn-primary">Tambah</button>
                  </div>

                </div>

              </div>
            </div><!-- End Recent Sales -->
      

<?php echo $__env->yieldContent('content'); ?>
<?php $__env->stopSection(); ?>
                
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PERURI\hros\resources\views/mdtvkabel.blade.php ENDPATH**/ ?>