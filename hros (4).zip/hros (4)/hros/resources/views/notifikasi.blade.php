<!DOCTYPE html>
<html lang="en">

<head>
@extends('layout.master')

@section('content')
</head>

<body>
<div class="m-3">
<div class="container px-4">
  <div class="row gx-5">
    <div class="col">
        <div style="box-sizing: border-box; position: absolute; width: 300px; height: 300px; left: 480px; top: 170px;
            background: #FFFFFF; border: 1.7695px solid rgba(6, 40, 61, 0.79); border-radius: 17.695px;">
            <div style="position: absolute; width: 50px; height: 50px;left: 130.49px; top: 50.08px; background: url(assets/verif.png);"></div>
            <p style="position: absolute; left: 25.69%; right: 36.26%; top: 57.36%; bottom: 37.98%; font-family: 'Roboto'; font-style: normal; font-weight: 400;
                font-size: 20px; line-height: 41px; color: rgba(6, 40, 61, 0.79);">Data Berhasil Ditambahkan</p>
        </div>
    </div>
  </div>
</div>
</div>
</body>
</html>