

<?php $__env->startSection('content'); ?>

<div class="m-3">
<div class="container px-4">
  <div class="row gx-5">
    <div class="col">
        <div style="box-sizing: border-box; position: absolute; width: 500px; height: 400px; left: 360px; top: 135px;
            background: #FFFFFF; border: 1px solid rgba(19, 99, 223, 0.53); border-radius: 10px;">
            <div style="position: absolute; width: 100px; height: 100px; left: 210px; top: 50px; background: url(assets/logo.png);"></div>
            <div style= "margin-top: 180px; margin-left: 70px; font-family: 'Poppins'; font-style: normal; font-weight: 600; font-size: 15px; line-height: 20px;" >
                <p>User          :<p>
                <p>Nama Admin    :<p>
                <p>NP            :<p>
                <p>Username      :<p>
                <p>Password      :<p>
            </div>
            <input class="form-control form-control-sm" type="text" placeholder="User" style="position: absolute; width: 200px; height: 15px; left: 175px; top: 175px;
                background: #FFFFFF; border: 1px solid #B5B5B5; border-radius: 10px;">
            <input class="form-control form-control-sm" type="text" placeholder="Nama Admin" style="position: absolute; width: 200px; height: 15px; left: 175px; top: 210px;
                background: #FFFFFF; border: 1px solid #B5B5B5; border-radius: 10px;">
            <input class="form-control form-control-sm" type="text" placeholder="NP" style="position: absolute; width: 200px; height: 15px; left: 175px; top: 245px;
                background: #FFFFFF; border: 1px solid #B5B5B5; border-radius: 10px;">
            <input class="form-control form-control-sm" type="text" placeholder="Username" style="position: absolute; width: 200px; height: 15px; left: 175px; top: 280px;
                background: #FFFFFF; border: 1px solid #B5B5B5; border-radius: 10px;">
            <input class="form-control form-control-sm" type="text" placeholder="Password" style="position: absolute; width: 200px; height: 15px; left: 175px; top: 315px;
                background: #FFFFFF; border: 1px solid #B5B5B5; border-radius: 10px;">
            <button type="submit" class="btn btn-primary btn-block mb-4" style="position: absolute;width: 80px; height: 40px; left: 370px;
                top: 350px; background: #1363DF; box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25); border-radius: 12.5px;;">
                <div class="text-center" style="font-family: 'Roboto'; font-style: normal; font-weight: 500; font-size: 16px;">
                    <p>Selesai</p>
                </div>
            </button>
        </div>

    </div>
  </div>
</div>
</div>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PERURI\hros\resources\views/editprofilit.blade.php ENDPATH**/ ?>