<!DOCTYPE html>
<html lang="en">

<head>
    

  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Bubblegum+Sans&family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  
  <!-- Vendor CSS Files -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>

    <?php $__env->startSection('content'); ?>

</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top  header-transparent ">
    <div class="container d-flex align-items-center justify-content-between"></div>

      <nav id="navbar" class="navbar">

  </header><!-- End Header -->


    <div class="position-relative">

    <div style= "width: 801px; height: 641px; left: 369px; top: 187px; background: #FFF2F2; border-radius: 50px; margin-top: 200px; margin-left: 525px; padding-top: 3%;">
    <div style= "width: 485px; height: 320px; background: url(assets/new.png); margin-top: 50px; margin-left: 90px; display:inline-block;"> </div>
    <div style= "margin-left: 50px;">
        <button style= "width: 176px; height: 44px; left: 372px; top: 233px; background: #1363DF;">
            <div style= "font-family: 'Poppins'; font-style: normal; font-weight: 400; font-size: 25px; line-height: 45px; text-align:center;"> Edit Profile </div>
        </button>
    </div>
    </div>
    <div style= "margin-top: 100px; margin-left: 40px;" >
        <div style= "font-family: 'Poppins'; font-style: normal; font-weight: 600; font-size: 25px; line-height: 38px;"> User            : AdminSDM </div>
        <div style= "font-family: 'Poppins'; font-style: normal; font-weight: 600; font-size: 25px; line-height: 38px;"> Nama            : Ibu Okta </div>
        <div style= "font-family: 'Poppins'; font-style: normal; font-weight: 600; font-size: 25px; line-height: 38px;"> Username        : AdminSDMO </div>
        <div style= "font-family: 'Poppins'; font-style: normal; font-weight: 600; font-size: 25px; line-height: 38px;"> Password        : 123456 </div>
    </div>
  </div>




<a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

<!-- Vendor JS Files -->
<script src="<?php echo e(asset('assets/vendor/aos/aos.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/glightbox/js/glightbox.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/swiper/swiper-bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/php-email-form/validate.js')); ?>"></script>

<!-- Template Main JS File -->
<script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>

</body>
<?php $__env->stopSection(); ?>

</html>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PERURI\hros\resources\views/notifikasi.blade.php ENDPATH**/ ?>