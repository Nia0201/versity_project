

<?php $__env->startSection('content'); ?>

<div class="m-3">
<div class="container px-4">
  <div class="row gx-5">
    <div class="col">
      <button class="border-0" type="submit" style="position: absolute; /*padding-left: 230px; padding-top: 245px;*/
        width: 50px;height: 50px;left: 75.5px; top: 95.5px;background: url(assets/back3.png);">
      </button>
      <div style="position: absolute; width: 1032.5px; height: 35.5px; left: 155px; top: 105.5px;
        background: #DFF6FF; border-radius: 10px;">
        <div class="text-center" style="font-family: 'Roboto'; font-style: normal; color: rgba(6, 40, 61, 0.79); font-weight: 400; font-size: 25.5px">
          <p>Edit Verfikasi Internet</p>
        </div>
      </div>
      <p style="position: absolute; left: 12.42%; right: 75.56%; top: 27.71%; bottom: 81.64%; font-family: 'Roboto';
        font-style: normal; font-weight: 600; font-size: 25.5px; line-height: 38px; color: rgba(6, 40, 61, 0.79);">Tempat: </p>
      <button class="border-0" style="position: absolute;left: 23.61%; right: 66.32%; top: 27.71%; bottom: 81.64%; font-family: 'Roboto';
        font-style: normal; font-weight: 400; font-size: 25px; line-height: 38px; color: rgba(6, 40, 61, 0.79);">Karawang
      </button>
      <button class="border-0" style="position: absolute;left: 23.61%; right: 40.32%; top: 27.71%; bottom: 81.64%; font-family: 'Roboto';
        font-style: normal; font-weight: 400; font-size: 25px; line-height: 38px; color: rgba(6, 40, 61, 0.79);">Jakarta
      </button>
      <p style="position: absolute; left: 12.42%; right: 75.56%; top: 38.71%; bottom: 65.64%; font-family: 'Roboto';
          font-style: normal; font-weight: 500; font-size: 20.5px; line-height: 38px; color: rgba(6, 40, 61, 0.79);">Bulan Pemakaian: </p>
      <select class="custom-select mr-sm-2" id="inlineFormCustomSelect" style="position: absolute; width: 150.5px; height: 30.5px; left: 320.5px;
        top: 225px; background: #FFFFFF; border: 2.5px solid #D9D9D9;">
        <option selected>Choose...</option>
        <option value="1">Januari</option>
        <option value="2">Februari</option>
        <option value="3">Maret</option>
        <option value="4">April</option>
        <option value="5">Mei</option>
        <option value="6">Juni</option>
        <option value="7">Juli</option>
        <option value="8">Agustus</option>
        <option value="9">September</option>
        <option value="10">Oktober</option>
        <option value="11">November</option>
        <option value="12">Desember</option>
      </select>
      <p style="position: absolute; left: 50.42%; right: 30.56%; top: 40.71%; bottom: 65.64%; font-family: 'Roboto';
          font-style: normal; font-weight: 500; font-size: 20.5px; line-height: 38px; color: rgba(6, 40, 61, 0.79);">Jenis Internet: </p>
      <select class="custom-select mr-sm-2" id="inlineFormCustomSelect" style="position: absolute; width: 150.5px; height: 30.5px; left: 780.5px;
        top: 235px; background: #FFFFFF; border: 2.5px solid #D9D9D9;">
        <option selected>Choose...</option>
        <option value="1">Indihome</option>
      </select>
      <p style="position: absolute; left: 12.42%; right: 75.56%; top: 45.71%; bottom: 65.64%; font-family: 'Roboto';
          font-style: normal; font-weight: 500; font-size: 18.5px; line-height: 38px; color: rgba(6, 40, 61, 0.79);">Bulan Pembayaran: </p>
      <select class="custom-select mr-sm-2" id="inlineFormCustomSelect" style="position: absolute; width: 150.5px; height: 30.5px; left: 320.5px;
        top: 265px; background: #FFFFFF; border: 2.5px solid #D9D9D9;">
        <option selected>Choose...</option>
        <option value="1">Januari</option>
        <option value="2">Februari</option>
        <option value="3">Maret</option>
        <option value="4">April</option>
        <option value="5">Mei</option>
        <option value="6">Juni</option>
        <option value="7">Juli</option>
        <option value="8">Agustus</option>
        <option value="9">September</option>
        <option value="10">Oktober</option>
        <option value="11">November</option>
        <option value="12">Desember</option>
      </select>
      <div class="input-group rounded" >
        <input type="Search" class="form-control rounded" placeholder="Search" aria-label="Search" aria-describedby="search-addon" style="position: absolute; width: 400px; height: 30.5px; left: 600.5px; top: 148.5px;
        background: #FFFFFF; border: 2.5px solid rgba(6, 40, 61, 0.79); border-radius: px;"/>
        <span class="input-group-text border-0" id="search-addon">
          <i class="fas fa-search"></i>
        </span>
        <button class="border-0" style="position: absolute; width: 20px; height: 20px; left: 1003.5px; top: 153.5px; background: url(assets/cari.png)";></button>
      </div>
      <div class="table table-striped table-bordered table-sm " cellspacing="0" width="100%">
        <table class="table table-hover" style="position: absolute; width: 1140px;mheight: 792.5px; left: 60px; top: 350.5px;">
          <thead>
            <tr>
              <th width="70px" scope="col">No Telepon</th>
              <th width="100px" scope="col">Pemakaian</th>
              <th width="250px" scope="col">Biaya Admin</th>
              <th width="270px" scope="col">Total</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <th scope="row">1</th>
              <td>Mark</td>
              <td>Otto</td>
              <td>@mdo</td>
            </tr>
            <tr>
              <th scope="row">2</th>
              <td>Jacob</td>
              <td>Thornton</td>
              <td>@fat</td>
            </tr>
            <tr>
              <th scope="row">3</th>
              <td>Larry</td>
              <td>the Bird</td>
              <td>@twitter</td>
            </tr>
            <tr>
              <th scope="row">3</th>
              <td>Larry</td>
              <td>the Bird</td>
              <td>@twitter</td>
            </tr>
            <tr>
              <th scope="row">3</th>
              <td>Larry</td>
              <td>the Bird</td>
              <td>@twitter</td>
            </tr>
            <tr>
              <th scope="row">3</th>
              <td>Larry</td>
              <td>the Bird</td>
              <td>@twitter</td>
            </tr>
            <tr>
              <th scope="row">3</th>
              <td>Larry</td>
              <td>the Bird</td>
              <td>@twitter</td>
            </tr>
            <tr>
              <th scope="row">3</th>
              <td>Larry</td>
              <td>the Bird</td>
              <td>@twitter</td>
            </tr>
            <tr>
              <th scope="row">3</th>
              <td>Larry</td>
              <td>the Bird</td>
              <td>@twitter</td>
            </tr>
            <tr>
              <th scope="row">3</th>
              <td>Larry</td>
              <td>the Bird</td>
              <td>@twitter</td>
            </tr>
          </tbody>
        </table>
      </div>
      <div>
        <button type="submit" class="btn btn-primary btn-block mb-4" style="position: absolute;width: 100px; height: 35px; left: 1050px;
          top: 820px; background: #1363DF; box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25); border-radius: 12.5px;;">
            <div class="text-center" style="font-family: 'Roboto'; font-style: normal; font-weight: 500; font-size: 16px;">
              <p>Kembali</p>
            </div>
        </button>
      </div>
    </div>
  </div>
</div>
</div>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PERURI\hros\resources\views/editverifinternet.blade.php ENDPATH**/ ?>