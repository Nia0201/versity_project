<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PulsaController extends Controller
{
    //
}
